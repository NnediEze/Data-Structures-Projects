public class BigO implements BigOInterface {
    
    //constructor
    public BigO(){};
    
    //public methods
    public void cubic(int n){
        long startTime = System.nanoTime();
        int sum = 0;
        for (int i=0; i < n; i++){
            for (int j=0; j < n; j++){
                for(int k=0; k < n; k++){
                    sum -= n;         
                }
            }
        }
        long endTime = System.nanoTime();
        System.out.println(endTime-startTime);
    }
    
	public void exp(int n){
        long startTime = System.nanoTime();
        this.recursive(n);
        long endTime = System.nanoTime();
        System.out.println(endTime-startTime);
    }
    
	public void constant(int n){
        long startTime = System.nanoTime();
        int y = n*n;
        long endTime = System.nanoTime();
        System.out.println(endTime-startTime);   
    }
    
    //private helper methods
    private int recursive(int n){
        if(n == 0 || n == 1){
            return 1; 
        }
        else{
            return recursive(n-1) * recursive(n-2);
        }    
    }
   
}