public class Rectangle implements RectangleInterface, Comparable<Rectangle> {
    
    //instance variables
    private double width;
    private double length;
    
    //constructor
    public Rectangle(double w, double l) {
        width = w;
        length = l;
    }
    
    //public methods
    public double getLength(){
        return length;
    }
    
    public double getWidth(){
        return width;
    }
    
    public int compareTo(Rectangle rect){
        if(this.getPerimeter() < rect.getPerimeter()){
            return -1;
        }
        
        else if(this.getPerimeter() > rect.getPerimeter()){
            return 1;
        }
        
        else{
            return 0;
        }   
    }
    
    //private helper methods
    private double getPerimeter(){
        return (2 * (this.getLength() + this.getWidth()));
    }
    
}
