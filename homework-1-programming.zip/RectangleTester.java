public class RectangleTester {
    public static void main(String[] args){
        Rectangle rect1 = new Rectangle(5,4);
        Rectangle rect2 = new Rectangle(3,2);
        
        System.out.println(rect1.compareTo(rect2));
        System.out.println(rect2.compareTo(rect1));
        
        rect1 = new Rectangle(1,3);
        rect2 = new Rectangle(1,3);
        
        System.out.println(rect1.compareTo(rect2));
    }   
}