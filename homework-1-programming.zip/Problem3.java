public class Problem3 {
    public static void main(String[] args){
        int[] cub = {1, 5, 10, 25, 35, 50, 70, 100, 1000};
        int[] exp = {1, 5, 7, 10, 15, 20, 25, 35};
        int[] con = {1, 10, 100, 1000, 10000, 100000, 1000000};
        
        BigO b = new BigO();
        
        for(int e1: cub){
            System.out.println("Cubic Runtime for n value: " + e1);
            b.cubic(e1);
        }
        
        System.out.println();
        
        for(int e2: exp){
            System.out.println("Exponential Runtime for n value: " + e2);
            b.exp(e2);
        }
        
        System.out.println();
        
        for(int e3: con){
            System.out.println("Constant Runtime for n value: " + e3);
            b.constant(e3);
        }
    }  
    
}