import java.util.Arrays;

public class GenericMethodsTester {
    public static void main(String[] args) {
        Rectangle[] rect = new Rectangle[4];
        rect[0] = new Rectangle(5,3);
        rect[1] = new Rectangle(8,2);
        rect[2] = new Rectangle(7,1);
        rect[3] = new Rectangle(4,6);
        
        GenericMethods gm = new GenericMethods();
        
        System.out.println(gm.linearSearch(rect, new Rectangle(8,2)));
        System.out.println(gm.linearSearch(rect, new Rectangle(3,9)));
        
        System.out.println();
        
        Arrays.sort(rect);
        System.out.println(gm.binarySearch(rect, new Rectangle(8,2)));
        System.out.println(gm.binarySearch(rect, new Rectangle(4,6)));
        System.out.println(gm.linearSearch(rect, new Rectangle(6,7)));
      
    }
}