import java.util.Arrays;

public class GenericMethods implements GenericMethodsInterface {
    
    //constructor
    public GenericMethods() {}; 

    //public methods
    public <AnyType extends Comparable<AnyType>> int linearSearch(AnyType[] a, AnyType x) {
        for(int i=0; i < a.length; i++){
            if(a[i].compareTo(x) == 0){
                return i;
            }
        }
        return -1;
    }
    
    public <AnyType extends Comparable<AnyType>> int binarySearch(AnyType[] a, AnyType x){
        return binarySearch(a, x, a.length-1, 0);
    }
    
    //private helper methods
    private <AnyType extends Comparable<AnyType>> int binarySearch(AnyType[] a, AnyType x, int right, int left){
            if (left <= right){
                int mid = left + ((right-left)/2);
       
                if(a[mid].compareTo(x) == 0){
                    return mid;
                }
                else if(a[mid].compareTo(x) == -1){
                    left = mid + 1;
                    return binarySearch(a,x,right,left);
                }
                else if(a[mid].compareTo(x) == 1){
                    right = mid - 1;
                    return binarySearch(a,x,right,left);
                }
            }
            return -1;
    }
}