public interface RectangleInterface {
    
	public double getLength();
	public double getWidth();
}
