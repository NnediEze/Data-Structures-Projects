public class TwoStackQueue<T> implements TwoStackQueueInterface<T>{
    /*instance variables*/
    MyStack s1;
    MyStack s2;
    int size;
    
    /*constructor*/
    public TwoStackQueue(){
        s1 = new MyStack();
        s2 = new MyStack();
        size = 0;
    };
    
    /*methods*/
    public void enqueue(T x){  
        s1.push(x);
        size++;
        this.reverse();
        
    }
	public T dequeue(){
        size--;
        return (T) s2.pop();
    }
    
	public int size(){
        return size;
    }
    
	public boolean isEmpty(){
        if(size == 0){
            return true;
            
        }
        
        return false;
    }	
    
    public void reverse(){
        for(int i = 0; i < size; i++){
            s2.push(s1.pop());
            
        }
        
    }
    
}