import java.util.Arrays;

public class MyStack<T> implements MyStackInterface<T>{
    
    /*instance variables*/
    private static final int default_capacity = 10;
    int size;
    T[] stack;
    
    /*constructor*/
    public MyStack() {
        stack = (T[]) new Object[default_capacity];
        size = 0;
    }
    
    /*Methods*/
    public void push(T x){
        if(size+1 == stack.length){
            this.resize();       
        }
       
        stack[size++] = x;  
    }
    
	public T pop(){
        if(size-1 == -1){
            System.out.println("ERROR: Stack Underflow | Cannot remove item from an empty stack.");
        }
        
        return stack[--size];
    }
    
	public T peek(){
        return stack[size-1];
    }
    
	public boolean isEmpty(){
        if(size == 0){
            return true;
        }
        
        return false;
    }
    
	public int size(){
        return size;
    }
    
    public void resize(){
        T[] temp = Arrays.copyOf(stack, size*2);
        stack = temp;
    } 
    
    
}