public interface BalanceError {
}
