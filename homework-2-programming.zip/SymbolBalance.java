import java.io.*;
import java.util.Scanner;

public class SymbolBalance implements SymbolBalanceInterface {
    /*instance variables*/
    MyStack stack; 
    File inFile;
    int lineCount;
    
    /*constructor*/
    public SymbolBalance(){
        stack = new MyStack();
        lineCount = 0;
    };
    
    /*methods*/
    public void setFile(String filename){
        inFile = new File(filename); 
    }
       
	public BalanceError checkFile(){
        try{
            Scanner input = new Scanner(inFile);
            while (input.hasNext()){
                String s = input.nextLine();
                lineCount++;
                for(int i= 0; i < s.length(); i++){
                    if(s.charAt(i) == '{' || s.charAt(i) == '('){
                        stack.push(s.charAt(i));
                    }   
                    else if(s.charAt(i) == '[' || s.charAt(i) == '"'){
                        stack.push(s.charAt(i));
                    }                   
                    else if(s.charAt(i) == '}'){
                        if(stack.isEmpty()) {
                            return new EmptyStackError(lineCount);
                        }
                        else if((char) stack.peek() != '{'){
                            return new MismatchError(lineCount, '{', (char) stack.peek());
                        }
                        else{
                            stack.pop();
                        }
                    }              
                    else if(s.charAt(i) == ')'){
                        if(stack.isEmpty()) {
                            return new EmptyStackError(lineCount);
                        }
                        else if((char) stack.peek() != '('){
                            return new MismatchError(lineCount, '(', (char) stack.peek());
                        
                        }
                        else{
                            stack.pop();
                        }
                    }
                    else if(s.charAt(i) == ']'){
                        if(stack.isEmpty()) {
                            return new EmptyStackError(lineCount);
                        }
                        else if((char) stack.peek() != '['){
                            return new MismatchError(lineCount, '[', (char) stack.peek());
                        }
                        else{
                            stack.pop();
                        }
                    }
                    else if(s.charAt(i) == '"'){
                        if((char) stack.peek() != '"'){
                            stack.push('"');
                            Scanner input2 = input;
                            while(input2.hasNext()){
                                String s2 = input2.nextLine();
                                    for(int j= 0; j < s2.length(); j++){
                                        if (s.charAt(j) == '"'){
                                            stack.pop();
                                             break;
                                        }
                                    }
                            }

                            return new NonEmptyStackError('"', stack.size());
                        }
                        else{
                            stack.pop();
                        }
                    }
                    else if(s.charAt(i) == '*'){
                        if((char) stack.peek() != '*'){
                            stack.push('*');
                            Scanner input3 = input;
                            while(input3.hasNext()){
                                String s2 = input3.nextLine();
                                    for(int k= 0; k < s2.length(); k++){
                                        if(s.charAt(k) == '*'){
                                            stack.pop();
                                             break;
                                         }
                                    }
                            }

                            return new NonEmptyStackError('*', stack.size());
                        }
                        else{
                            stack.pop();
                        }
                    }      
                }  
            }
        
            if(!stack.isEmpty()){
                return new NonEmptyStackError((char) stack.peek(), lineCount); 
            }
        }
        catch(FileNotFoundException e){
            System.out.print("Invalid File Input | File not Found");
        }
        return null;
    }      
}