import java.lang.Math;
import java.util.LinkedList;
public class BetterBST<T extends Comparable<? super T>> extends BinarySearchTree<T>{
    /**CONSTRUCTORS**/
    
    public BetterBST(){
        super();
    }
    
    public BetterBST(BinaryNode<T> root){
        super();
        this.root = root;
    }
    
    /**PUBLIC DRIVER METHODS**/
    public int height(){
        return this.height(this.root);       
    }
	public T imbalance(){
        return this.imbalance(this.root);    
    }
    
	public T smallestGreaterThan(T t){
        if(this.root == null){
            return (T) null;
        }
        if(this.root.right == null){
            if(this.root.data.compareTo(t) > 0){
                return this.root.data;
            }
            else{
                return (T) null;
            }
        }
        
        return this.findMin();  
    }
    
    public BinarySearchTree<T> mirror(){
        return new BetterBST(this.mirror(this.root)); 
    }
    
	public void prettyPrint(){
        this.prettyPrint(this.root);
    }
    /**PRIVATE HELPER METHODS**/
    /**
     * recursive postfix traversal determines height of BST
     * @param root is root of BST
     */ 
    private int height(BinaryNode<T> root){   
        if(root.right == null && root.left == null){
            return -1;
        }
        
        int lheight = height(root.left);
        int rheight = height(root.right);
        
        return Math.max(lheight, rheight) + 1;        
    }
    /**
     * returns root of new BST with switched left and right subtrees
     * @param root is root of BST
     */ 
    private BinaryNode<T> mirror(BinaryNode<T> root){
        if(root == null){
            return null;
        }
        
        BinaryNode<T> temp = root.right;
        root.right = root.left;
        root.left = temp;
        
        return new BinaryNode<T>(root.data, mirror(root.right), mirror(root.left));    
    }
    /**
     * checks for imabalance in BST using recursive height() method
     * @param root is root of BST
     */ 
    private T imbalance(BinaryNode<T> root){
        if(root == null){
            return null;
        }
        
        int lheight = height(root.left);
        int rheight = height(root.right);
        
        
        if(Math.abs(lheight - rheight) <= 1 && imbalance(root.right) == null || imbalance(root.left) == null){
            return root.data;
        }
        
        return null;
    }
    
  
    private void prettyPrint(BinaryNode<T> root){
        if(root == null){
            System.out.println("Null Node");
        }
        
        LinkedList<T> lqueue = new LinkedList<T>();
        LinkedList<T> rqueue = new LinkedList<T>();
        
        lqueue.add(fillLeft(root));
        rqueue.add(fillRight(root));
        
        int h = height(root);
        String space = "";
        
        while(h >= 0){
            for(int i = 0; i < h; i++){
                space += " ";    
            }
            System.out.println(space + lqueue.getFirst() + space + rqueue.getFirst() + space);
            h--;
        }
    }
    //fills lqueue
    public T fillLeft(BinaryNode<T> root){
          if(root == null){
              return (T) " ";
          }
          if(root.left == null && root.right == null){
               return root.data;
          }
 
          return fillLeft(root.left);
    }
    //fills rqueue    
    public T fillRight(BinaryNode<T> root){
           if(root == null){
              return (T) " ";
           }
           if(root.left == null && root.right == null){
               return root.data;
           }
           
           return fillRight(root.right);
    }
   
}
