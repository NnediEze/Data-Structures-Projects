public class ExpressionTreeTester {
    public static void main(String[] args){
        String test1 = "6 7 + 8 *";
        String test2 = "5";
        String test3 = "9 0 6 +"; //error stack overflow
        String test4 = "6 /"; //error stack underflow
        String test5 = "7 9 - 50 + 9 *"; 
        
        ExpressionTree tree1 = new ExpressionTree(test1);
        System.out.println(tree1.eval());
        System.out.println(tree1.postfix());
        System.out.println(tree1.prefix());
        System.out.println(tree1.infix());
        
        System.out.println();
        
        ExpressionTree tree2 = new ExpressionTree(test2);
        System.out.println(tree2.eval());
        System.out.println(tree2.postfix());
        System.out.println(tree2.prefix());
        System.out.println(tree2.infix());
        
        System.out.println();
        
        ExpressionTree tree5 = new ExpressionTree(test5);
        System.out.println(tree5.eval());
        System.out.println(tree5.postfix());
        System.out.println(tree5.prefix());
        System.out.println(tree5.infix());
        
        ExpressionTree tree3 = new ExpressionTree(test3);
        System.out.println(tree3.eval());
        System.out.println(tree3.postfix());
        System.out.println(tree3.prefix());
        System.out.println(tree3.infix());
        
        ExpressionTree tree4 = new ExpressionTree(test4);
        System.out.println(tree4.eval());
        System.out.println(tree4.postfix());
        System.out.println(tree4.prefix());
        System.out.println(tree4.infix());
     
    }
}