public class BetterBSTTester{
    public static void main(String[] args){
        BetterBST<Integer> tree = new BetterBST<Integer>();
        tree.root = new BinaryNode<Integer>(6, null, null);
    }
}