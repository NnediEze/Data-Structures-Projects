/** ExpressionTree.java
 *  binary expression tree that implements ExpressionTreeInterface
 *  using stack data sructure
 */
import java.util.LinkedList;
import java.util.Scanner;
public class ExpressionTree implements ExpressionTreeInterface{
    private LinkedList<ExpressionNode<String>> tree;
    /** 
     * constructs tree 
     * @param expression is a postfix expression of type String
     * contains only integer operands and following operators: +,-,*,/
     */
    public ExpressionTree(String expression){
        try{
            tree = new LinkedList<ExpressionNode<String>>();
            Scanner input = new Scanner(expression);
       
            while(input.hasNext()){
                String s = input.next();
                if(isInteger(s)){
                    tree.push(new ExpressionNode(s, null, null));
                }
                else{
                    tree.push(new ExpressionNode(s, tree.pop(), tree.pop()));
                }
            }
            if(tree.size() > 1){
                throw new Exception("Error: Stack Overflow, missing operators in expression");  
            }
        }    
        catch(RuntimeException e1){
            System.out.println("Error: Stack Underflow, missing operands in expression");
        }
        catch(Exception e2){
            System.out.println(e2);      
        }
    }
    /**
     * checks if input is an operand
     * @param s input string from postfix expression
     */
    public boolean isInteger(String s){
        try{
            Integer.parseInt(s);
            return true;
        }
        catch(NumberFormatException e){
            return false;   
        }       
    }
    /**
     * private static class for nodes in the expression tree
     */
    private static class ExpressionNode<String> {
        ExpressionNode(String d, ExpressionNode<String> r, ExpressionNode<String> l){
            data = d;
            left= l;
            right = r;
        }
        
        public String data; 
        public ExpressionNode<String> left;
        public ExpressionNode<String> right;      
    }
    /**PUBLIC DRIVER METHODS **/
    public int eval(){
        try{
            if(tree.size() > 1){
                throw new Exception();
            }
            
            return this.eval(tree.peek());
        }
        catch(NullPointerException e){
            return 0;
        }
        catch(Exception e){
            return 0;
        }     
    }
	public String postfix(){
        try{
            if(tree.size() > 1){
                throw new Exception();
            }
            return this.postfix(tree.peek());
        }
        catch(NullPointerException e){
            return null;
        }
        catch(Exception e){
            return null;
        } 
    }
	public String prefix(){
        try{
            if(tree.size() > 1){
                throw new Exception();
            }
            
            return this.prefix(tree.peek());
        }
        catch(NullPointerException e){
            return null;
        }
        catch(Exception e){
            return null;
        } 
    }
	public String infix(){
        try{
            if(tree.size() > 1){
                throw new Exception();
            }
            
            return this.infix(tree.peek());
        }
        catch(NullPointerException e){
            return null;
        }
        catch(Exception e){
            return null;
        } 
    }    
    /**PRIVATE HELPER METHODS**/    
    private int eval(ExpressionNode<String> root) throws NullPointerException{
        if(root.left == null && root.right == null){
            return Integer.parseInt(root.data);
        }
        else{
            if(root.data.equals("*")){
                return eval(root.left) * eval(root.right);
            }
            else if(root.data.equals("/")){
                return eval(root.left) / eval(root.right);
            }
            else if(root.data.equals("-")){
                return eval(root.left) - eval(root.right);
            }
            
            return eval(root.left) + eval(root.right);
        }  
    }
    
   private String postfix(ExpressionNode<String> root) throws NullPointerException{
       if(root.left == null && root.right == null){
           return root.data + " "; 
       }
       
       return postfix(root.left) + " " + postfix(root.right) + root.data;
   }
   
   private String prefix(ExpressionNode<String> root) throws NullPointerException{
       if(root.left == null && root.right == null){
          return root.data + " ";
       }
          
       return root.data + " " + prefix(root.left) + prefix(root.right);        

   }
   
   private String infix(ExpressionNode<String> root) throws NullPointerException{
       if(root.left == null && root.right == null){
           return root.data + " ";
       }
       
       return infix(root.left) + root.data + " " + infix(root.right);   
   }
}