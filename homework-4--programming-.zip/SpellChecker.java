/*
 * SpellChecker.java - checks for incorrect words in string files and can make suggestions
 */ 

import java.io.*;
import java.util.*;

public class SpellChecker implements SpellCheckerInterface {
    
    /**Instance Variables**/
    private HashSet<String> dictionary;
    private ArrayList<String> incorrectWords; 
    private HashSet<String> suggestions;
    
    /**Constructor**/
    public SpellChecker(String filename){
        try{
            incorrectWords = new ArrayList<String>();
            suggestions = new HashSet<String>();
            dictionary = new HashSet<String>();
            
            String word;
            File infile = new File(filename);
            Scanner input = new Scanner(infile);
            while(input.hasNext()){
                word = input.next().toLowerCase();
                dictionary.add(word);
            }
            input.close();
        }
        
        catch(FileNotFoundException e){
            System.out.println("ERROR: Cannot find file");
        }
    }
    
    /**Public Methods**/
    public List<String> getIncorrectWords(String filename){
        try{
            String word;
            File infile = new File(filename);
            Scanner input = new Scanner(infile);
            while(input.hasNext()){
                word = input.next().replaceAll("\\p{Punct}", "").toLowerCase();
                if(!dictionary.contains(word)){
                    incorrectWords.add(word);
                }
            }
            input.close();
        }
        
        catch(FileNotFoundException e){
            System.out.println("ERROR: Cannot find file");
        }
        
        return incorrectWords;  
    }
    
	public Set<String> getSuggestions(String word){
        StringBuffer suggestion;
        //insert character at each point in word
        String alphabet = "abcdefghijklmnopqrstuvwxyz";
        for(int i=0; i < word.length()+1; i++){
            for(int j=0; j < alphabet.length(); j++){
                suggestion = new StringBuffer(word);
                suggestion = suggestion.insert(i, alphabet.substring(j,j+1));
                if(dictionary.contains(suggestion.toString())){
                    suggestions.add(suggestion.toString());
                }
            }
        }
        //remove one character at a time from word
        for(int i=0; i < word.length(); i++){
            suggestion = new StringBuffer(word);
            suggestion = suggestion.deleteCharAt(i);
            if(dictionary.contains(suggestion.toString())){
                suggestions.add(suggestion.toString());
            }
        }
        //swap adjacent characters in word
        for(int i=0; i < word.length() - 1; i++){
            suggestion = new StringBuffer(word);
            char temp = word.charAt(i);
            suggestion.setCharAt(i, word.charAt(i+1));
            suggestion.setCharAt(i+1, temp);
            if(dictionary.contains(suggestion.toString())){
                suggestions.add(suggestion.toString());
            }     
        }
            
        return suggestions;
    }
}