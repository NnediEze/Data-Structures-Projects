/*
 * KBestCounter.java - finds k-largest elements in given sequence
 */ 

import java.util.*;

public class KBestCounter<T extends Comparable<? super T>> implements KBest<T>{
    /**Instance Variables**/
     private PriorityQueue<T> minHeap;
     private ArrayList<T> theKbest;
     private int listSize;
    
    /**Constructor**/
    public KBestCounter(int k){
        minHeap = new PriorityQueue<T>();
        theKbest = new ArrayList<T>();
        listSize = k;
    }
    
    /**Public Methods**/
    public void count(T x){
        try{
            if(listSize <= 0){
                throw new Exception("ERROR: Invalid k-value. Cannot count " + String.valueOf(listSize) + " values");
            }
            
            if(minHeap.size() == listSize){
                if(x.compareTo(minHeap.peek()) > 0){
                    minHeap.poll();
                    minHeap.add(x);
                }  
            }
    
            else{
                minHeap.add(x);
            }
        }
        catch(Exception e){
            System.out.println(e);
        }
    }
    
    public List<T> kbest(){
        while(minHeap.size() > 0){
            theKbest.add(minHeap.poll());
        }
        
        return theKbest;
    }  
}