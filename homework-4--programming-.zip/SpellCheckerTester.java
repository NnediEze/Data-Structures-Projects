public class SpellCheckerTester{
    public static void main(String[] args){
        SpellChecker checker1 = new SpellChecker("words.txt");
        System.out.println(checker1.getIncorrectWords("test.txt"));
        for(String element : checker1.getIncorrectWords("test.txt")){
            checker1.getSuggestions(element);      
        }
        System.out.println(checker1.getSuggestions(""));
    }
}