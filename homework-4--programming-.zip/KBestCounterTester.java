import java.util.*;

public class KBestCounterTester{
    public static void main(String[] args){
        KBestCounter<Double> t = new KBestCounter<Double>(4);
        ArrayList<Double> ints = new ArrayList<Double>();
    
        while(ints.size() < 10){
            ints.add(Math.random());
        }
        
        for(Double element: ints){
            t.count(element);
        }
        
        System.out.println(t.kbest());
        
        
     
        
    }  
}